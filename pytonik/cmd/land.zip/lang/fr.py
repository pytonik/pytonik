{"lng.test": "Exemple de texte"}
