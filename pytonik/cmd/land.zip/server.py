from pytonik import serv

serv.run(host="localhost", path="", port=6060)
