from pytonik.Server import Server

Server.serve(host="localhost", path="", port=60)
